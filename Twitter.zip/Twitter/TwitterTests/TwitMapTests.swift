//
//  TwitMapTests.swift
//  TwitterTests
//
//  Created by Admin on 03/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import XCTest
class TwitMapTests: XCTestCase {

    func getMapJson() -> String
    {
        return "{\"statuses\":[{\"created_at\":\"Sat Sep 28 20:00:03 +0000 2019\",\"id\":1178036671100547072,\"id_str\":\"1178036671100547072\",\"text\":\"1.8 magnitude #earthquake. 15 km from Hidden Valley Lake, #CA, United States https:\\\\\t.co\\3i9TZoYtwX\",\"truncated\":false,\"entities\":{\"hashtags\":[{\"text\":\"earthquake\",\"indices\":[14,25]},{\"text\":\"CA\",\"indices\":[58,61]}],\"symbols\":[],\"user_mentions\":[],\"urls\":[{\"url\":\"https:\\\\\t.co\\3i9TZoYtwX\",\"expanded_url\":\"http:\\ \\ www.earthquaketrack.com\\ quakes\\ 2019-09-28-19-56-48-utc-1-8-4\",\"display_url\":\"earthquaketrack.com\\ quakes\\ 2019-09\\u2026\",\"indices\":[77,100]}]},\"metadata\":{\"iso_language_code\":\"en\",\"result_type\":\"recent\"},\"source\":\"\\u003ca href=\\\"http:\\ \\ earthquaketrack.com\\\" rel=\\\"nofollow\\\"\\u003eEarthquakeTrack.com\\u003c\\ a\\u003e\",\"in_reply_to_status_id\":null,\"in_reply_to_status_id_str\":null,\"in_reply_to_user_id\":null,\"in_reply_to_user_id_str\":null,\"in_reply_to_screen_name\":null,\"user\":{\"id\":362523555,\"id_str\":\"362523555\",\"name\":\"Earthquake Alerts\",\"screen_name\":\"QuakesToday\",\"location\":\"\",\"description\":\"Worldwide earthquake alerts based on USGS data.  1.5 magnitude and higher.\",\"url\":\"http:\\ \\ t.co\\ rgn1EPhfEq\",\"entities\":{\"url\":{\"urls\":[{\"url\":\"http:\\ \\ t.co\\ rgn1EPhfEq\",\"expanded_url\":\"http:\\ \\ earthquaketrack.com\",\"display_url\":\"earthquaketrack.com\",\"indices\":[0,22]}]},\"description\":{\"urls\":[]}},\"protected\":false,\"followers_count\":173107,\"friends_count\":10,\"listed_count\":1266,\"created_at\":\"Fri Aug 26 14:57:52 +0000 2011\",\"favourites_count\":21,\"utc_offset\":null,\"time_zone\":null,\"geo_enabled\":true,\"verified\":false,\"statuses_count\":281691,\"lang\":null,\"contributors_enabled\":false,\"is_translator\":false,\"is_translation_enabled\":false,\"profile_background_color\":\"C0DEED\",\"profile_background_image_url\":\"http:\\ \\ abs.twimg.com\\ images\\ themes\\ theme1\\ bg.png\",\"profile_background_image_url_https\":\"https:\\ \\ abs.twimg.com\\ images\\ themes\\ theme1\\ bg.png\",\"profile_background_tile\":false,\"profile_image_url\":\"http:\\ \\ pbs.twimg.com\\ profile_images\\ 2433994816\\ qvn5ctift622bdsult18_normal.png\",\"profile_image_url_https\":\"https:\\ \\ pbs.twimg.com\\ profile_images\\ 2433994816\\ qvn5ctift622bdsult18_normal.png\",\"profile_banner_url\":\"https:\\ \\ pbs.twimg.com\\ profile_banners\\ 362523555\\ 1392962242\",\"profile_link_color\":\"1DA1F2\",\"profile_sidebar_border_color\":\"C0DEED\",\"profile_sidebar_fill_color\":\"DDEEF6\",\"profile_text_color\":\"333333\",\"profile_use_background_image\":true,\"has_extended_profile\":false,\"default_profile\":true,\"default_profile_image\":false,\"following\":null,\"follow_request_sent\":null,\"notifications\":null,\"translator_type\":\"none\"},\"geo\":{\"type\":\"Point\",\"coordinates\":[38.755,-122.4]},\"coordinates\":{\"type\":\"Point\",\"coordinates\":[-122.4,38.755]},\"place\":{\"id\":\"fbd6d2f5a4e4a15e\",\"url\":\"https:\\ \\ api.twitter.com\\ 1.1\\ geo\\ id\\ fbd6d2f5a4e4a15e.json\",\"place_type\":\"admin\",\"name\":\"California\",\"full_name\":\"California, USA\",\"country_code\":\"US\",\"country\":\"United States\",\"contained_within\":[],\"bounding_box\":{\"type\":\"Polygon\",\"coordinates\":[[[-124.482003,32.528832],[-114.131212,32.528832],[-114.131212,42.009519],[-124.482003,42.009519]]]},\"attributes\":{}},\"contributors\":null,\"is_quote_status\":false,\"retweet_count\":0,\"favorite_count\":0,\"favorited\":false,\"retweeted\":false,\"possibly_sensitive\":false,\"lang\":\"en\"},{\"created_at\":\"Sat Sep 28 19:59:02 +0000 2019\",\"id\":1178036412265840641,\"id_str\":\"1178036412265840641\",\"text\":\"USGS reports a M1.81 #earthquake 15km ESE of Hidden Valley Lake, CA on 9\\ 28\\ 19 @ 19:56:48 UTC https:\\ \\ t.co\\ E66ve71ztY #quake\",\"truncated\":false,\"entities\":{\"hashtags\":[{\"text\":\"earthquake\",\"indices\":[21,32]},{\"text\":\"quake\",\"indices\":[118,124]}],\"symbols\":[],\"user_mentions\":[],\"urls\":[{\"url\":\"https:\\ \\ t.co\\ E66ve71ztY\",\"expanded_url\":\"https:\\ \\ earthquake.usgs.gov\\ earthquakes\\ eventpage\\ nc73282785\",\"display_url\":\"earthquake.usgs.gov\\ earthquakes\\ ev\\u2026\",\"indices\":[94,117]}]},\"metadata\":{\"iso_language_code\":\"en\",\"result_type\":\"recent\"},\"source\":\"\\u003ca href=\\\"http:\\ \\ everyearthquake.com\\\" rel=\\\"nofollow\\\"\\u003eeveryEarthquake\\u003c\\ a\\u003e\",\"in_reply_to_status_id\":null,\"in_reply_to_status_id_str\":null,\"in_reply_to_user_id\":null,\"in_reply_to_user_id_str\":null,\"in_reply_to_screen_name\":null,\"user\":{\"id\":1414684496,\"id_str\":\"1414684496\",\"name\":\"Every Earthquake\",\"screen_name\":\"everyEarthquake\",\"location\":\"Earth\",\"description\":\"Tweeting every earthquake occurrence reported by USGS.  Built and maintained by David Barkman aka @cybler.\",\"url\":\"http:\\ \\ t.co\\ F96blurVzC\",\"entities\":{\"url\":{\"urls\":[{\"url\":\"http:\\ \\ t.co\\ F96blurVzC\",\"expanded_url\":\"http:\\ \\ everyearthquake.com\",\"display_url\":\"everyearthquake.com\",\"indices\":[0,22]}]},\"description\":{\"urls\":[]}},\"protected\":false,\"followers_count\":16901,\"friends_count\":1,\"listed_count\":333,\"created_at\":\"Thu May 09 05:36:42 +0000 2013\",\"favourites_count\":6,\"utc_offset\":null,\"time_zone\":null,\"geo_enabled\":true,\"verified\":false,\"statuses_count\":428376,\"lang\":null,\"contributors_enabled\":false,\"is_translator\":false,\"is_translation_enabled\":false,\"profile_background_color\":\"131516\",\"profile_background_image_url\":\"http:\\ \\ abs.twimg.com\\ images\\ themes\\ theme14\\ bg.gif\",\"profile_background_image_url_https\":\"https:\\ \\ abs.twimg.com\\ images\\ themes\\ theme14\\ bg.gif\",\"profile_background_tile\":true,\"profile_image_url\":\"http:\\ \\ pbs.twimg.com\\ profile_images\\ 3634178223\\ 68e03a9e08624dd2c2306d2293587bcc_normal.jpeg\",\"profile_image_url_https\":\"https:\\ \\ pbs.twimg.com\\ profile_images\\ 3634178223\\ 68e03a9e08624dd2c2306d2293587bcc_normal.jpeg\",\"profile_link_color\":\"009999\",\"profile_sidebar_border_color\":\"EEEEEE\",\"profile_sidebar_fill_color\":\"EFEFEF\",\"profile_text_color\":\"333333\",\"profile_use_background_image\":true,\"has_extended_profile\":false,\"default_profile\":false,\"default_profile_image\":false,\"following\":null,\"follow_request_sent\":null,\"notifications\":null,\"translator_type\":\"none\"},\"geo\":{\"type\":\"Point\",\"coordinates\":[38.7546654,-122.4004974]},\"coordinates\":{\"type\":\"Point\",\"coordinates\":[-122.4004974,38.7546654]},\"place\":{\"id\":\"fbd6d2f5a4e4a15e\",\"url\":\"https:\\ \\ api.twitter.com\\ 1.1\\ geo\\ id\\ fbd6d2f5a4e4a15e.json\",\"place_type\":\"admin\",\"name\":\"California\",\"full_name\":\"California, USA\",\"country_code\":\"US\",\"country\":\"United States\",\"contained_within\":[],\"bounding_box\":{\"type\":\"Polygon\",\"coordinates\":[[[-124.482003,32.528832],[-114.131212,32.528832],[-114.131212,42.009519],[-124.482003,42.009519]]]},\"attributes\":{}},\"contributors\":null,\"is_quote_status\":false,\"retweet_count\":0,\"favorite_count\":0,\"favorited\":false,\"retweeted\":false,\"possibly_sensitive\":false,\"lang\":\"en\"}],\"search_metadata\":{\"completed_in\":0.027,\"max_id\":1178036671100547072,\"max_id_str\":\"1178036671100547072\",\"next_results\":\"?max_id=1178036412265840640&q=&geocode=38.773972%2C-122.431297%2C5km&count=100&include_entities=1&result_type=recent\",\"query\":\"\",\"refresh_url\":\"?since_id=1178036671100547072&q=&geocode=38.773972%2C-122.431297%2C5km&result_type=recent&include_entities=1\",\"count\":100,\"since_id\":0,\"since_id_str\":\"0\"}}"
    }
    
    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testTweets() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        
        if let data = getMapJson().data(using: .utf8) {
            do {
                let jsonDict = try JSONSerialization.jsonObject(with: data, options: []) as! NSDictionary
                print(jsonDict)
                let tweets = NSMutableArray()
                Parser.parseJson(dataDict: jsonDict, tweets: tweets, isCoordinateRequired: true)
                XCTAssertTrue(tweets.count > 0)
            } catch {
                print(error.localizedDescription)
            }
        }
    }

    func testFailedTweets()
    {
        let tweets = NSMutableArray()
        XCTAssertTrue(tweets.count > 0)
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
