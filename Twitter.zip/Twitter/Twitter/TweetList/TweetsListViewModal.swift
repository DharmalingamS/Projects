//
//  TweetsListViewModal.swift
//  Twitter
//
//  Created by Admin on 03/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation

class TweetsListViewModal: NSObject {
    weak var tweetListView : TweetListView!
    weak var tweetListControllerRef : TweetsListViewController!
    var tweets = NSMutableArray()
    
    //Hitting server to get tweets based on hashtag and keyword
    func loadTweets(hashTag : String, keyword : String)
    {
        let client = TWTRAPIClient()
        var clientError : NSError?
        tweetListView.showLoadingIndicator()
        let statusesShowEndpoint = "https://api.twitter.com/1.1/search/tweets.json?q=hashtag=\(hashTag)&keyword=\(keyword)"
        
        let request = client.urlRequest(withMethod: "GET", urlString: statusesShowEndpoint, parameters: nil, error: &clientError)
        
        client.sendTwitterRequest(request) { (response, data, connectionError) -> Void in
            if connectionError != nil {
                print("Error: \(String(describing: connectionError))")
            }
            else
            {
                do {
                    let jsonDict = try JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary
                    Parser.parseJson(dataDict: jsonDict, tweets: self.tweets, isCoordinateRequired: false)
                    self.tweetListView.reloadTable()
                } catch let jsonError as NSError {
                    print("json error: \(jsonError.localizedDescription)")
                }
            }
        }
    }
    
    //Reload Tweets search list
    func reloadTable(){
        tweetListView.reloadTable()
    }
    
    //UITableViewDataSource
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return tweetListView.numberOfSections(in: tableView)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tweetListView.tableView(tableView, numberOfRowsInSection: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return tweetListView.tableView(tableView, cellForRowAt: indexPath)
    }
    
    //UITableViewDelegate
    func tableView(tableView: UITableView,
                   willDisplayCell cell: UITableViewCell,
                   forRowAtIndexPath indexPath: NSIndexPath)
    {
        tweetListView.tableView(tableView: tableView, willDisplayCell: cell, forRowAtIndexPath: indexPath)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return tweetListView.tableView(tableView, heightForRowAt: indexPath)
    }
    
    //UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return tweetListView.textFieldShouldReturn(textField)
    }
    
}
