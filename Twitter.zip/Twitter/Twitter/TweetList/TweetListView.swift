//
//  TweetListView.swift
//  Twitter
//
//  Created by Admin on 03/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation

class TweetListView: UIView {
    @IBOutlet weak var tableView : UITableView!
    @IBOutlet weak var hashTagTxtFld : UITextField!
    @IBOutlet weak var keywordTxtFld : UITextField!
    var loadingIndicator : UIActivityIndicatorView!
    weak var tweetListControllerRef : TweetsListViewController!
    
    //Swipe Gesture to pop list from stack to display map or to navigate from tweet list to map
    func setUpGesture()
    {
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipped(gesture:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.addGestureRecognizer(swipeRight)
    }
    
    @objc func swipped(gesture: UISwipeGestureRecognizer)
    {
        tweetListControllerRef.navigationController?.popViewController(animated: true)
    }
    
    //Loading Indicator while hitting a service
    func showLoadingIndicator()
    {
        loadingIndicator = UIActivityIndicatorView.init(style: .whiteLarge)
        loadingIndicator.startAnimating()
        loadingIndicator.center = self.center
        loadingIndicator.backgroundColor = UIColor.gray
        DispatchQueue.main.async {
            self.addSubview(self.loadingIndicator)
        }
    }
    
    func reloadTable(){
        DispatchQueue.main.async {
            self.tableView.reloadData()
            self.loadingIndicator.removeFromSuperview()
        }
    }
    
    //UITableViewDataSource
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tweetListControllerRef.tweetListViewModal.tweets.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tweets = tweetListControllerRef.tweetListViewModal.tweets
        let cellIdentifier = "TweetCell"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
        if(cell == nil)
        {
            let tweet = tweets.object(at: indexPath.row) as! Tweet
            let user : User = tweet.user
            cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle, reuseIdentifier: cellIdentifier)
            cell?.textLabel?.text = user.userName as String?
            cell?.detailTextLabel?.text = (tweets.object(at: indexPath.row) as! Tweet).text as String?
            cell?.detailTextLabel?.numberOfLines = 0
            
            cell?.backgroundColor = UIColor(red: 29/256, green: 161/256, blue: 242/256, alpha: 1.0)
        }
        return cell ?? UITableViewCell()
    }
    
    //UITableViewDelegate
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 150
    }
    
    func tableView(tableView: UITableView,
                   willDisplayCell cell: UITableViewCell,
                   forRowAtIndexPath indexPath: NSIndexPath)
    {
        let additionalSeparatorThickness = CGFloat(3)
        let additionalSeparator = UIView(frame: CGRect(x: 0, y: cell.frame.size.height - additionalSeparatorThickness, width: cell.frame.size.width, height: additionalSeparatorThickness))
        additionalSeparator.backgroundColor = UIColor.white
        cell.addSubview(additionalSeparator)
    }
    
    //UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        hashTagTxtFld.resignFirstResponder()
        keywordTxtFld.resignFirstResponder()
        return true
    }
    
    //Tweet Search Button Action
    @IBAction func searchButtonAction(button : UIButton)
    {
        hashTagTxtFld.resignFirstResponder()
        keywordTxtFld.resignFirstResponder()
        tweetListControllerRef.tweetListViewModal.loadTweets(hashTag: hashTagTxtFld.text!, keyword: keywordTxtFld.text!)
    }
    
}
