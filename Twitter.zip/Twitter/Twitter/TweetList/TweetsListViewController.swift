//
//  TweetsList.swift
//  Twitter
//
//  Created by Admin on 30/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
class TweetsListViewController: UIViewController,UITableViewDelegate,UITableViewDataSource, UITextFieldDelegate {
    @IBOutlet weak var tweetListView : TweetListView!
    var tweetListViewModal = TweetsListViewModal()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tweetListViewModal.tweetListView = tweetListView
        tweetListViewModal.tweetListControllerRef = self
        tweetListViewModal.tweetListView.tweetListControllerRef = self
        tweetListViewModal.loadTweets(hashTag: "", keyword: "")
        tweetListViewModal.tweetListView.setUpGesture()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    //UITableViewDataSource
    func numberOfSections(in tableView: UITableView) -> Int {
        return tweetListViewModal.tweetListView.numberOfSections(in: tableView)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tweetListViewModal.tableView(tableView, numberOfRowsInSection: section)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return tweetListViewModal.tableView(tableView, cellForRowAt: indexPath)
    }
    
    //UITableViewDelegate
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        tweetListViewModal.tableView(tableView: tableView, willDisplayCell: cell, forRowAtIndexPath: indexPath as NSIndexPath)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return tweetListViewModal.tweetListView.tableView(tableView, heightForRowAt: indexPath)
    }
    
    //UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return tweetListViewModal.textFieldShouldReturn(textField)
    }
}
