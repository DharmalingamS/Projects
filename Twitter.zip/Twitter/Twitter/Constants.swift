//
//  Constants.swift
//  Twitter
//
//  Created by Admin on 28/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

let customerKey = "1KsjYo873asGJO2Zk7alG3yTR"
let customerSecret = "5SS2FmEN7GOE40lz8ASatYlb8qja8RtRVA37VvudvWIruXn2eW"
let accessTokenKey = "556571077-hyoNp3vGBYXXcz4OuRcWnFJfHg76w5e76Vvf4Ocs"
let accessTokenSecret = "IjaD27uNjTlbjuFakBZt8fzOMcqu20o0IodwBUY03vAvI"
let radius = 5
let maxTweetCount = 100
