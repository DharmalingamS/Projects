//
//  TweetDetailViewModal.swift
//  Twitter
//
//  Created by Admin on 03/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
class TweetDetailViewModal : NSObject
{
    weak var tweetDetaiControllerRef : TweetDetailViewController!
    weak var tweetDetailView : TweetDetailView!
    var tweet : Tweet!
    
    func setUpUI(twt : Tweet)
    {
        tweet = twt
        self.tweetDetailView.setUpUIWithTweet(twt: self.tweet!)
    }
    
    //Hitting retweet service
    func reTweet()
    {
        let client = TWTRAPIClient()
        let endPoint = "https://api.twitter.com/1.1/statuses/retweet/\(tweet.tweetID!).json"
        var clientError : NSError?
        
        let request = client.urlRequest(withMethod: "POST", urlString: endPoint, parameters: nil, error: &clientError)
        
        client.sendTwitterRequest(request) { (response, data, error) in
            guard error == nil else{return}
            
            let httpResponse = response as! HTTPURLResponse
            if httpResponse.statusCode == 200
            {
                DispatchQueue.main.async {
                    self.tweetDetaiControllerRef.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
}
