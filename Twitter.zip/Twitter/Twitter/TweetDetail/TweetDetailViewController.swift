//
//  TweetDetailViewController.swift
//  Twitter
//
//  Created by Admin on 30/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
class TweetDetailViewController: UIViewController {
    @IBOutlet weak var tweetDetailView : TweetDetailView!
    let tweetDetailModal = TweetDetailViewModal()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tweetDetailView.tweetDetaiControllerRef = self
        tweetDetailModal.tweetDetailView = tweetDetailView
        tweetDetailModal.tweetDetaiControllerRef = self
    }
}
