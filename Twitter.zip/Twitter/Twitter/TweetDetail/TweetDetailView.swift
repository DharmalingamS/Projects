//
//  TweetDetailView.swift
//  Twitter
//
//  Created by Admin on 03/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
class TweetDetailView : UIView
{
    @IBOutlet weak var profileImage : UIImageView!
    @IBOutlet weak var userName : UILabel!
    @IBOutlet weak var descriptionTxtView : UITextView!
    weak var tweetDetaiControllerRef : TweetDetailViewController!
    
    //Setup UI
    func setUpUIWithTweet(twt : Tweet)
    {
        profileImage.layer.cornerRadius = 30
        profileImage.image = twt.user.downloadedProfileImage
        userName.text = twt.user.userName as String?
        descriptionTxtView.text = twt.text as String?
        descriptionTxtView.layer.cornerRadius = 30
    }
    
    /*
     Retweet the tweet
     Currently it is not working since my account does not have permission
     */
    @IBAction func reTweet(button : UIButton)
    {
        tweetDetaiControllerRef.tweetDetailModal.reTweet()
    }
    
    @IBAction func close(button : UIButton)
    {
        tweetDetaiControllerRef.dismiss(animated: true, completion: nil)
    }
}
