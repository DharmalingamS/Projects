//
//  ViewController.swift
//  Twitter
//
//  Created by Admin on 25/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit
import MapKit
class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var mapView : MapView!
    let mapViewModal = MapViewModal()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        mapViewModal.controllerRef = self
        mapViewModal.mapView = mapView
        mapViewModal.mapView.controllerRef = self
        mapViewModal.checkLocationAuthorizationStatus()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        mapViewModal.initiatePreviousLocation()
    }
    
    //MKMapViewDelegate
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        mapViewModal.mapView(mapView, didUpdate: userLocation)
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        return mapViewModal.mapView(mapView, viewFor: annotation)
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        mapViewModal.mapView(mapView, didSelect: view)
    }
    
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        mapViewModal.mapView(mapView, didDeselect: view)
    }
    
    //CLLocationManagerDelegate
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        mapViewModal.locationManager(manager, didUpdateLocations: locations)
    }
    
}

