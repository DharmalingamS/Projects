//
//  CustomAnnotationView.swift
//  Twitter
//
//  Created by Admin on 30/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation

class CustomAnnotationView: UIView {
    @IBOutlet weak var userImage : UIImageView!
    @IBOutlet weak var titleLbl : UILabel!
    @IBOutlet weak var descriptionLbl : UILabel!
    weak var controllerRef : ViewController?
    var tweet : Tweet?
    //Set up data to pop up
    func setUpUI()
    {
        self.layer.cornerRadius = 30;
        userImage.layer.cornerRadius = 30
        titleLbl.text = self.tweet?.user.userName as String?
        descriptionLbl.text = self.tweet?.text as String?
        if (self.tweet?.user.downloadedProfileImage == nil)
        {
            let profileImage = (self.tweet!.user.profileImage)! as String
            DispatchQueue.global().async { [weak self] in
                if let data = try? Data(contentsOf: URL(string: profileImage)!) {
                    if let image = UIImage(data: data) {
                        self?.tweet?.user.downloadedProfileImage = image
                        DispatchQueue.main.async {
                            self?.userImage.image = image
                        }
                    }
                }
            }
        }
        else
        {
            self.userImage.image = self.tweet?.user.downloadedProfileImage
        }
    }
    
    //Show tweet details
    @IBAction func showDetail(button : UIButton)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "TweetDetailViewController") as! TweetDetailViewController
        controllerRef!.present(controller, animated: true, completion: nil)
        controller.tweetDetailModal.setUpUI(twt: self.tweet!)
    }
    
}

