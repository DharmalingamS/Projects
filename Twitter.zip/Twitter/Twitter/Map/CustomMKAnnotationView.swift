//
//  CustomMKAnnotationView.swift
//  Twitter
//
//  Created by Admin on 30/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
import MapKit

class CustomMKAnnotationView: MKPinAnnotationView {
    
    //Hit Test te recognize where the user tapped on popup
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let hitView = super.hitTest(point, with: event)
        if hitView != nil
        {
            self.superview?.bringSubviewToFront(self)
        }
        return hitView
    }
    
    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        let rect = self.bounds
        var isTappedInside = rect.contains(point)
        if !isTappedInside
        {
            for view in self.subviews
            {
                isTappedInside = view.frame.contains(point)
                if isTappedInside
                {
                    break
                }
            }
        }
        return isTappedInside
    }
}
