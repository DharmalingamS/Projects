//
//  MapView.swift
//  Twitter
//
//  Created by Admin on 03/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
import MapKit
class MapView : UIView
{
    @IBOutlet weak var map: MKMapView!
    weak var controllerRef : ViewController?
    var currentAnnotationView : CustomAnnotationView!
    
    //Place tweet marker on map
    func placeMarkerForTweet(tweet : Tweet, markers : NSMutableArray)
    {
        DispatchQueue.main.async {
            let marker = MKPointAnnotation()
            marker.coordinate = tweet.geoLocation
            self.map.addAnnotations([marker])
            markers.add(marker)
        }
    }
    
    //Remove tweet marker from map
    func removeMarkerForTweet(tweet : Tweet, tweets : NSMutableArray, markers : NSMutableArray)
    {
        if(tweets.contains(tweet))
        {
            let tweetIndex = tweets.index(of: tweet)
            let marker = markers.object(at: tweetIndex)
            DispatchQueue.main.async {
                self.map.removeAnnotation(marker as! MKAnnotation)
            }
            markers.remove(marker)
            tweets.remove(tweet)
        }
    }
    
    //CustomAnnotationView
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        if annotation is MKUserLocation {
            return nil
        }
        guard annotation is MKPointAnnotation else { return nil }
        
        let identifier = "Annotation"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
        
        if annotationView == nil {
            annotationView = CustomMKAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView!.canShowCallout = true
        } else {
            annotationView!.annotation = annotation
        }
        
        return annotationView
    }
    
    //Centralizing the map
    func setRegionOfMapForLocation(location : CLLocation)
    {
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        self.map.setRegion(region, animated: true)
    }
    
    //Creating customized popup when tap marker
    func configureDetailView(annotationView: MKAnnotationView, markers : NSMutableArray, tweets : NSMutableArray) {
        let view =  Bundle.main.loadNibNamed("CustomAnnotationView", owner: self, options: nil)?.first as? CustomAnnotationView
        let annotation = annotationView.annotation
        let index = markers.index(of: annotation as Any)
        view?.tweet = (tweets.object(at: index) as! Tweet)
        view!.center = CGPoint(x: annotationView.bounds.size.width / 2, y: -view!.bounds.size.height*0.52)
        annotationView.addSubview(view!)
        currentAnnotationView = view
        currentAnnotationView.controllerRef = controllerRef
        view?.setUpUI()
    }
    
    //Remove Custom Annotation View
    func removeCustomAnnnotationView()
    {
        currentAnnotationView.removeFromSuperview()
    }
    
    //Action
    //Show tweet list
    @IBAction func showTweetList(button : UIButton)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "TweetsListViewController") as! TweetsListViewController
        controllerRef!.navigationController?.pushViewController(controller, animated: true)
    }
}
