//
//  MapViewModel.swift
//  Twitter
//
//  Created by Admin on 03/10/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
import MapKit

class MapViewModal : NSObject
{
    let locationManager = CLLocationManager()
    var previousLocation : CLLocationCoordinate2D!
    
    var tweets = NSMutableArray()
    var markers = NSMutableArray()
    weak var mapView : MapView!
    weak var controllerRef : ViewController?
    
    //Get distance between 2 location to get new set of tweets if distance btw current and previous current location is greater than 100 mts
    func getDistanceBetween(location1 : CLLocationCoordinate2D, location2 : CLLocationCoordinate2D) -> CLLocationDistance
    {
        let loc1 = CLLocation(latitude: location1.latitude, longitude: location1.longitude)
        let loc2 = CLLocation(latitude: location2.latitude, longitude: location2.longitude)
        
        return loc1.distance(from: loc2)
    }
    
    //Previous offset location initialization
    func initiatePreviousLocation()
    {
        previousLocation = mapView.map.userLocation.coordinate
    }
    
    //Placing tweets over map
    func placeNewTweets()
    {
        for tweet in tweets
        {
            mapView.placeMarkerForTweet(tweet: tweet as! Tweet, markers: markers)
        }
    }
    
    //Removing all tweets from mapS
    func removeAllTweets()
    {
        for tweet in tweets
        {
            mapView.removeMarkerForTweet(tweet: tweet as! Tweet, tweets : tweets, markers : markers)
        }
    }
    
    //Hitting service to get tweets
    func loadTweetsForLocation(location : CLLocationCoordinate2D)
    {
        let client = TWTRAPIClient()
        let statusesShowEndpoint = "https://api.twitter.com/1.1/search/tweets.json?q=&geocode=\(location.latitude),\(location.longitude),\(radius)km&result_type=recent&count=\(maxTweetCount)&coordinates=true&place=true"
        var clientError : NSError?
        
        let request = client.urlRequest(withMethod: "GET", urlString: statusesShowEndpoint, parameters: nil, error: &clientError)
        
        client.sendTwitterRequest(request) { (response, data, connectionError) -> Void in
            if connectionError != nil {
                print("Error: \(String(describing: connectionError))")
            }
            else
            {
                do {
                    self.removeAllTweets()
                    let jsonDict = try JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary
                    Parser.parseJson(dataDict: jsonDict, tweets: self.tweets, isCoordinateRequired: true)
                    self.placeNewTweets()
                    self.previousLocation = self.mapView.map.userLocation.coordinate
                } catch let jsonError as NSError {
                    print("json error: \(jsonError.localizedDescription)")
                }
            }
        }
    }
    
    //Asking for permission to allow location access
    func checkLocationAuthorizationStatus() {
        mapView.map.delegate = controllerRef
        mapView.map.showsUserLocation = true
        locationManager.delegate = controllerRef
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            locationManager.startUpdatingLocation()
            locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        } else{
            locationManager.requestWhenInUseAuthorization()
        }
    }
    
    //MKMapViewDelegate
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation)
    {
        self.mapView.setRegionOfMapForLocation(location: userLocation.location!)
        if (self.getDistanceBetween(location1: userLocation.location!.coordinate, location2: previousLocation) > 100)
        {
            self.loadTweetsForLocation(location: userLocation.location!.coordinate)
        }
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        return self.mapView.mapView(mapView, viewFor: annotation)
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView)
    {
        if !(view.annotation! is MKUserLocation) {
            self.mapView.configureDetailView(annotationView: view, markers: self.markers, tweets: self.tweets)
            self.mapView.setRegionOfMapForLocation(location: CLLocation(latitude: (view.annotation?.coordinate.latitude)!, longitude: (view.annotation?.coordinate.longitude)!))
        }
    }
    
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView)
    {
        self.mapView.removeCustomAnnnotationView()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        if let location = locations.last{
            self.mapView.setRegionOfMapForLocation(location: location)
        }
    }
}
