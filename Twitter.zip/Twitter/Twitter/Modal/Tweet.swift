//
//  Tweet.swift
//  Twitter
//
//  Created by Admin on 29/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
import MapKit

/*
 Tweet Modal Object is used to store each data which is fetched from twitter Rest API
 This is used in code while placing a marker over map using the geo cordinates of the tweet location
*/
class Tweet: NSObject {
    var tweetID     : NSInteger!
    var geoLocation : CLLocationCoordinate2D!
    var text        : NSString?
    var user        : User!
    var hashTag     : String?
}

