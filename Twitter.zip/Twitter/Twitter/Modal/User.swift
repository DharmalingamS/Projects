//
//  User.swift
//  Twitter
//
//  Created by Admin on 29/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
import UIKit
/*
  User objects holds the user details of the person who twitted
*/
class User : NSObject
{
    var userID          : NSInteger!
    var userName        : NSString!
    var userDescription : String?
    var location        : NSString?
    var profileImage    : NSString?
    var screenName      : NSString?
    var downloadedProfileImage : UIImage?
}
