//
//  Parser.swift
//  Twitter
//
//  Created by Admin on 30/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
import MapKit
class Parser: NSObject {
    
    //Checking whether data is available
    class func isDataAvailable(data : AnyObject?) -> Bool
    {
        return (data != nil && !(data?.isKind(of: NSNull.self))!)
    }
    
    //Parsing the tweet json
    class func parseJson(dataDict : NSDictionary, tweets : NSMutableArray, isCoordinateRequired : Bool)
    {
        let statuses : NSArray = dataDict.object(forKey: "statuses") as? NSArray ?? []
        for dict in statuses//index in 0...statuses.count - 1
        {
            let tweetDict : NSDictionary = dict as! NSDictionary//statuses[index] as! NSDictionary
            let tweet = Tweet()
            let user = User()
            tweet.tweetID = (tweetDict.object(forKey: "id") as! NSInteger)
            var geoLocation : CLLocationCoordinate2D?
            var geoCoordinates : NSDictionary?
            var coordinates : NSArray?
            if Parser.isDataAvailable(data: tweetDict.object(forKey: "geo") as AnyObject?)
            {
                geoCoordinates = tweetDict.object(forKey: "geo") as? NSDictionary
                coordinates = geoCoordinates?.object(forKey: "coordinates") as? NSArray
            }
            else if Parser.isDataAvailable(data: tweetDict.object(forKey: "coordinates") as AnyObject?)
            {
                geoCoordinates = tweetDict.object(forKey: "coordinates") as? NSDictionary
                let tempCoordinates = geoCoordinates?.object(forKey: "coordinates") as! NSArray
                coordinates = NSArray(objects: tempCoordinates[1] ,tempCoordinates[0])
            }
            
            if (coordinates != nil && coordinates!.count > 0)
            {
                geoLocation = CLLocationCoordinate2D(latitude: coordinates![0] as! CLLocationDegrees, longitude: coordinates![1] as! CLLocationDegrees)
            }
            else if(isCoordinateRequired)
            {
                continue
            }
            tweet.geoLocation = geoLocation
            tweet.text = tweetDict.object(forKey: "text") as? NSString
            let metaData = tweetDict.object(forKey: "entities") as! NSDictionary
            let hashTags = metaData.object(forKey: "hashtags") as! NSArray
            for hashTag in hashTags
            {
                let text = (hashTag as! NSDictionary).object(forKey: "text") as! String
                tweet.hashTag = text + " "
            }
            let userDict : NSDictionary = tweetDict.object(forKey: "user") as! NSDictionary
            user.userID = userDict.object(forKey: "id") as? NSInteger
            user.userName = userDict.object(forKey: "name") as? NSString
            user.userDescription = userDict.object(forKey: "description") as? String
            user.location = userDict.object(forKey: "location") as? NSString
            
            if (userDict.object(forKey: "profile_image_url_https") != nil)
            {
                user.profileImage = userDict.object(forKey: "profile_image_url_https") as? NSString
            }
            else  if (userDict.object(forKey: "profile_image_url") != nil)
            {
                user.profileImage = userDict.object(forKey: "profile_image_url") as? NSString
            }
            user.screenName = userDict.object(forKey: "screen_name") as? NSString
            
            tweet.user = user
            
            tweets.add(tweet)
        }
    }
    
}
